﻿using System;
using System.Windows;
using System.Windows.Controls; // For TextBox, Button, TextBlock

namespace Lab6_GeometricProgression
{
    /// <summary>
    /// Логіка взаємодії для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Обчислює суму геометричної прогресії за заданими параметрами.
        /// Формула:
        /// Якщо r = 1, Sn = a * n
        /// Якщо r ≠ 1, Sn = a * (1 - r^n) / (1 - r)
        /// </summary>
        /// <param name="a">Перший член прогресії.</param>
        /// <param name="r">Знаменник прогресії.</param>
        /// <param name="n">Кількість членів прогресії.</param>
        /// <returns>Сума геометричної прогресії.</returns>
        /// <exception cref="ArgumentException">Викидається, якщо кількість членів n від'ємна.</exception>
        private double CalculateGeometricProgressionSum(double a, double r, int n)
        {
            if (n < 0)
            {
                throw new ArgumentException("Кількість членів прогресії (n) не може бути від'ємною.");
            }

            if (n == 0)
            {
                return 0; // Сума нульової кількості членів дорівнює 0
            }

            if (r == 1.0)
            {
                // Якщо знаменник дорівнює 1, то кожен член прогресії дорівнює 'a'
                return a * n;
            }
            else
            {
                // Використовуємо формулу для r ≠ 1
                return a * (1.0 - Math.Pow(r, n)) / (1.0 - r);
            }
        }

        /// <summary>
        /// Обробник події натискання кнопки "Обчислити суму".
        /// Зчитує параметри прогресії з текстових полів, викликає функцію обчислення
        /// та виводить результат або повідомлення про помилку.
        /// </summary>
        /// <param name="sender">Об'єкт, що викликав подію (кнопка).</param>
        /// <param name="e">Аргументи події.</param>
        private void btnCalculateSum_Click(object sender, RoutedEventArgs e)
        {
            lblResult.Text = ""; // Очищаємо попередній результат
            lblError.Text = "";   // Очищаємо повідомлення про помилку

            double a, r;
            int n;

            // Парсинг першого члена (a)
            if (!double.TryParse(txtFirstTerm.Text, out a))
            {
                lblError.Text = "Помилка: Введіть коректне число для 'Перший член (a)'.";
                return;
            }

            // Парсинг знаменника (r)
            if (!double.TryParse(txtCommonRatio.Text, out r))
            {
                lblError.Text = "Помилка: Введіть коректне число для 'Знаменник (r)'.";
                return;
            }

            // Парсинг кількості членів (n)
            if (!int.TryParse(txtNumTerms.Text, out n))
            {
                lblError.Text = "Помилка: Введіть коректне ціле число для 'Кількість членів (n)'.";
                return;
            }

            try
            {
                double sum = CalculateGeometricProgressionSum(a, r, n);
                lblResult.Text = $"Сума геометричної прогресії: {sum:F4}"; // Форматуємо до 4 знаків після коми
            }
            catch (ArgumentException ex)
            {
                lblError.Text = $"Помилка вводу: {ex.Message}";
            }
            catch (Exception ex)
            {
                lblError.Text = $"Невідома помилка при обчисленні: {ex.Message}";
            }
        }
    }
}
